package com.example.flipsensor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

/** 화면이 꺼지거나 앱이 백그라운드여도 음악이 끊기지 않게 하는 포그라운드 서비스 */
class PlayerService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "음악 재생", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(ID, build(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refresh(this)
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        Player.stopAll()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    companion object {
        const val CH = "play"
        const val ID = 1

        @Volatile
        var running = false

        fun build(ctx: Context): Notification {
            val t = Player.current()
            val pi = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            return Notification.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(t?.title ?: "플립 플레이어")
                .setContentText(t?.artist ?: "")
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
        }

        fun refresh(ctx: Context) {
            if (running) {
                ctx.getSystemService(NotificationManager::class.java).notify(ID, build(ctx))
            }
        }
    }
}
