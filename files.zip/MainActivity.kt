package com.example.flipsensor

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sm: SensorManager
    private lateinit var web: WebView
    private val ui = Handler(Looper.getMainLooper())
    private var last = -1
    private var ready = false

    private val perm: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun granted() = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    private fun js(code: String) = web.evaluateJavascript(code, null)

    /** 재생 상태를 0.3초마다 웹 화면으로 전달 (화면에 보일 때만) */
    private val tick = object : Runnable {
        override fun run() {
            if (ready) js("window.onPlayer&&window.onPlayer(" + Player.stateJson() + ")")
            ui.postDelayed(this, 300)
        }
    }

    /** 웹 → 앱 호출 통로 */
    inner class Bridge {
        @JavascriptInterface fun hasPerm(): Boolean = granted()
        @JavascriptInterface fun askPerm() { runOnUiThread { askPermission() } }
        @JavascriptInterface fun tracks(): String = if (granted()) Player.loadJson(this@MainActivity) else "[]"
        @JavascriptInterface fun play(i: Int) { runOnUiThread { Player.play(i) } }
        @JavascriptInterface fun toggle() { runOnUiThread { Player.toggle() } }
        @JavascriptInterface fun next() { runOnUiThread { Player.next() } }
        @JavascriptInterface fun prev() { runOnUiThread { Player.prev() } }
        @JavascriptInterface fun seek(ms: Int) { runOnUiThread { Player.seek(ms) } }
        @JavascriptInterface fun playList(json: String, start: Int) {
            val ids = ArrayList<Long>()
            try {
                val a = JSONArray(json)
                for (k in 0 until a.length()) ids.add(a.getLong(k))
            } catch (e: Exception) {
                return
            }
            runOnUiThread { Player.playIds(ids, start) }
        }
        @JavascriptInterface fun loadPlaylists(): String =
            getSharedPreferences("flip", Context.MODE_PRIVATE).getString("pl", "[]") ?: "[]"
        @JavascriptInterface fun savePlaylists(s: String) {
            getSharedPreferences("flip", Context.MODE_PRIVATE).edit().putString("pl", s).apply()
        }
        @JavascriptInterface fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val bridge = Bridge()
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.textZoom = 100
            addJavascriptInterface(bridge, "DuoFlipNative")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(v: WebView?, u: String?) {
                    ready = true
                    if (last >= 0) push(last)
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    private fun askPermission() {
        val req = ArrayList<String>()
        req.add(perm)
        if (Build.VERSION.SDK_INT >= 33) req.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(req.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (ready) js("window.onPerm&&window.onPerm()")
    }

    override fun onResume() {
        super.onResume()
        sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
        ui.removeCallbacks(tick)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (!ready) {
            finish()
            return
        }
        // 열려 있는 mp3 탭/시트가 있으면 웹이 먼저 닫음
        web.evaluateJavascript("window.onBack?window.onBack():false") { r ->
            if (r != "true") {
                if (Player.playing) moveTaskToBack(true) else finish()
            }
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        last = e.values[0].toInt()
        if (ready) push(last)
    }

    private fun push(deg: Int) = web.post { js("window.setHinge($deg)") }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
