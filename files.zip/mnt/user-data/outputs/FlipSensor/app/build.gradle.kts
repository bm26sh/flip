plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.flipsensor"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.flipsensor"
        minSdk = 30
        targetSdk = 34
        versionCode = 3
        versionName = "2.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
