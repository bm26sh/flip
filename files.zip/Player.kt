package com.example.flipsensor

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.PowerManager
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

object Player {
    class Track(val id: Long, val title: String, val artist: String, val dur: Long, val uri: Uri)

    @Volatile var tracks: List<Track> = emptyList()
        private set
    @Volatile var index = -1
        private set

    private var mp: MediaPlayer? = null
    private var ready = false
    private var app: Context? = null
    private var focusReq: AudioFocusRequest? = null
    private var resumeOnGain = false
    @Volatile private var queueIds: List<Long> = emptyList()   // 비어 있으면 전체 목록
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    fun current(): Track? = tracks.getOrNull(index)

    val playing: Boolean
        get() = ready && try { mp?.isPlaying == true } catch (e: IllegalStateException) { false }

    /* ---------- 목록 ---------- */
    fun load(ctx: Context) {
        app = ctx.applicationContext
        val curId = current()?.id
        val list = ArrayList<Track>()
        val col = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        )
        val sel = "${MediaStore.Audio.Media.MIME_TYPE}=? OR ${MediaStore.Audio.Media.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("audio/mpeg", "%.mp3")
        val order = "${MediaStore.Audio.Media.DATE_ADDED} DESC"
        try {
            ctx.contentResolver.query(col, proj, sel, args, order)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iT = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iA = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iD = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val artist = c.getString(iA) ?: ""
                    list.add(
                        Track(
                            id,
                            c.getString(iT) ?: "(제목 없음)",
                            if (artist == "<unknown>") "" else artist,
                            c.getLong(iD),
                            ContentUris.withAppendedId(col, id)
                        )
                    )
                }
            }
        } catch (e: Exception) {
        }
        tracks = list
        index = if (curId == null) -1 else list.indexOfFirst { it.id == curId }
    }

    fun loadJson(ctx: Context): String {
        load(ctx)
        val arr = JSONArray()
        for (t in tracks) {
            arr.put(JSONObject().put("id", t.id).put("t", t.title).put("a", t.artist).put("d", t.dur))
        }
        return arr.toString()
    }

    /* ---------- 재생 제어 (메인 스레드에서 호출) ---------- */
    fun play(i: Int) {
        queueIds = emptyList()
        start(i, true)
    }

    /** 재생목록 재생: ids 순서대로 재생하고 끝나면 처음으로 돌아감 */
    fun playIds(ids: List<Long>, startPos: Int) {
        queueIds = ids
        val live = ids.filter { id -> tracks.any { it.id == id } }
        if (live.isEmpty()) return
        val sid = ids.getOrNull(startPos) ?: live[0]
        var i = tracks.indexOfFirst { it.id == sid }
        if (i < 0) i = tracks.indexOfFirst { it.id == live[0] }
        if (i >= 0) start(i, true)
    }

    fun toggle() {
        val ctx = app ?: return
        val m = mp
        if (m == null) {
            if (tracks.isNotEmpty()) start(if (index >= 0) index else 0, true)
            return
        }
        if (!ready) return
        try {
            if (m.isPlaying) {
                m.pause()
                stopFg(ctx)
            } else {
                focus(ctx)
                m.start()
                startFg(ctx)
            }
        } catch (e: IllegalStateException) {
        }
    }

    fun next() = step(1, true)

    fun prev() {
        if (pos() > 3000) seek(0) else step(-1, true)
    }

    fun seek(ms: Int) {
        if (!ready) return
        try { mp?.seekTo(ms) } catch (e: IllegalStateException) {}
    }

    fun stopAll() {
        release()
        app?.let { stopFg(it) }
    }

    private fun step(d: Int, user: Boolean) {
        val all = tracks
        if (all.isEmpty()) return
        val q: List<Long> =
            if (queueIds.isEmpty()) all.map { it.id }
            else queueIds.filter { id -> all.any { it.id == id } }
        if (q.isEmpty()) return
        val cid = current()?.id
        val pos = if (cid == null) -1 else q.indexOf(cid)
        val nid = if (pos < 0) q[0] else q[((pos + d) % q.size + q.size) % q.size]
        val ni = all.indexOfFirst { it.id == nid }
        if (ni >= 0) start(ni, user)
    }

    private fun start(i: Int, user: Boolean) {
        val ctx = app ?: return
        if (i !in tracks.indices) return
        release()
        index = i
        focus(ctx)
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(attrs)
            p.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            p.setDataSource(ctx, tracks[i].uri)
            p.setOnPreparedListener { m ->
                if (mp !== m) return@setOnPreparedListener
                ready = true
                m.start()
                if (user) startFg(ctx) else PlayerService.refresh(ctx)
            }
            p.setOnCompletionListener { m -> if (mp === m) step(1, false) }
            p.setOnErrorListener { m, _, _ ->
                if (mp === m) {
                    release()
                    stopFg(ctx)
                }
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            release()
        }
    }

    private fun release() {
        ready = false
        try { mp?.release() } catch (e: Exception) {}
        mp = null
    }

    /* ---------- 상태 ---------- */
    fun pos(): Int {
        if (!ready) return 0
        return try { mp?.currentPosition ?: 0 } catch (e: IllegalStateException) { 0 }
    }

    fun dur(): Int {
        if (ready) {
            val d = try { mp?.duration ?: 0 } catch (e: IllegalStateException) { 0 }
            if (d > 0) return d
        }
        return (current()?.dur ?: 0L).toInt()
    }

    fun stateJson(): String {
        val t = current()
        return JSONObject()
            .put("i", index)
            .put("id", t?.id ?: -1L)
            .put("p", playing)
            .put("pos", pos())
            .put("dur", dur())
            .put("t", t?.title ?: "")
            .put("a", t?.artist ?: "")
            .toString()
    }

    /* ---------- 오디오 포커스 / 서비스 ---------- */
    private fun focus(ctx: Context) {
        val am = ctx.getSystemService(AudioManager::class.java)
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { ch ->
                when (ch) {
                    AudioManager.AUDIOFOCUS_LOSS -> {
                        resumeOnGain = false
                        try { mp?.pause() } catch (e: IllegalStateException) {}
                    }
                    AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        resumeOnGain = playing
                        try { mp?.pause() } catch (e: IllegalStateException) {}
                    }
                    AudioManager.AUDIOFOCUS_GAIN -> if (resumeOnGain) {
                        resumeOnGain = false
                        try { mp?.start() } catch (e: IllegalStateException) {}
                    }
                }
            }
            .build()
            .also { focusReq = it }
        am.requestAudioFocus(req)
    }

    private fun startFg(ctx: Context) {
        try {
            ctx.startForegroundService(Intent(ctx, PlayerService::class.java))
        } catch (e: Exception) {
        }
    }

    private fun stopFg(ctx: Context) {
        ctx.stopService(Intent(ctx, PlayerService::class.java))
    }
}
